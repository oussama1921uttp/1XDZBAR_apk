package com.xdzbar.app;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/** جلسة المستخدم (يمرّرها الموقع بعد تسجيل الدخول) وقائمة الإشعارات التي أُرسلت. */
final class Session {
    private Session() {}

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("session", Context.MODE_PRIVATE);
    }

    static void save(Context c, String uid, String refreshToken) {
        SharedPreferences sp = prefs(c);
        String old = sp.getString("uid", null);
        SharedPreferences.Editor e = sp.edit();
        if (old != null && !old.equals(uid)) {   // حساب مختلف: نبدأ من جديد
            e.remove("seen").remove("base_inbox").remove("base_friendReq").remove("base_transfers");
        }
        e.putString("uid", uid).putString("refresh", refreshToken).apply();
    }

    static void updateRefresh(Context c, String refreshToken) {
        prefs(c).edit().putString("refresh", refreshToken).apply();
    }

    static void clear(Context c) {
        prefs(c).edit().clear().apply();
    }

    static String uid(Context c) { return prefs(c).getString("uid", null); }

    static String refresh(Context c) { return prefs(c).getString("refresh", null); }

    static boolean has(Context c) { return uid(c) != null && refresh(c) != null; }

    /** هل أخذنا اللقطة الأولى لهذا المسار؟ (حتى لا نُغرقك بإشعارات قديمة عند أول تشغيل) */
    static boolean baselineDone(Context c, String stream) {
        return prefs(c).getBoolean("base_" + stream, false);
    }

    static void setBaseline(Context c, String stream) {
        prefs(c).edit().putBoolean("base_" + stream, true).apply();
    }

    static boolean batteryAsked(Context c) { return prefs(c).getBoolean("battery_asked", false); }

    static void setBatteryAsked(Context c) { prefs(c).edit().putBoolean("battery_asked", true).apply(); }

    /** يسجّل أن هذا الإشعار أُرسل. يرجع false إن كان قد أُرسل من قبل. */
    static synchronized boolean markSeen(Context c, String key) {
        Set<String> seen = new HashSet<>(prefs(c).getStringSet("seen", new HashSet<String>()));
        if (!seen.add(key)) return false;
        if (seen.size() > 300) {   // نحتفظ بآخر مجموعة فقط
            Iterator<String> it = seen.iterator();
            while (seen.size() > 250 && it.hasNext()) {
                String k = it.next();
                if (!k.equals(key)) it.remove();
            }
        }
        prefs(c).edit().putStringSet("seen", seen).apply();
        return true;
    }
}
