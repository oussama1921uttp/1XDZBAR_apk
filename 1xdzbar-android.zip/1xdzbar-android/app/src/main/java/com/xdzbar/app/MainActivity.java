package com.xdzbar.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;

/** يعرض الموقع داخل WebView، ويمرّر جلسة المستخدم لخدمة الإشعارات. */
public class MainActivity extends Activity {

    /** صحيح عندما يكون التطبيق مفتوحاً أمامك (فلا نُظهر إشعارات مكرّرة). */
    static volatile boolean visible = false;

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);      // يحتاجه Firebase لحفظ تسجيل الدخول
        s.setDatabaseEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        CookieManager.getInstance().setAcceptCookie(true);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.setWebViewClient(new SiteClient());
        web.setWebChromeClient(new Dialogs());

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }

        if (Session.has(this)) startNotifyService();

        web.loadUrl(urlFrom(getIntent()));
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        web.loadUrl(urlFrom(intent));   // عند الضغط على إشعار: نفتح صفحته
    }

    @Override
    protected void onResume() {
        super.onResume();
        visible = true;
    }

    @Override
    protected void onPause() {
        visible = false;
        super.onPause();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    private String urlFrom(Intent intent) {
        String path = intent == null ? null : intent.getStringExtra("path");
        return Config.SITE + (path == null ? "" : path);
    }

    private void startNotifyService() {
        Intent i = new Intent(this, NotifyService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
        } catch (Exception ignored) { }
    }

    /** نطلب مرة واحدة استثناء التطبيق من توفير البطارية حتى تصل الإشعارات والشاشة مطفأة. */
    private void askIgnoreBatteryOptimizations() {
        if (Build.VERSION.SDK_INT < 23 || Session.batteryAsked(this)) return;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm == null || pm.isIgnoringBatteryOptimizations(getPackageName())) return;
        Session.setBatteryAsked(this);
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception ignored) { }
    }

    /** الموقع يستدعي هذه الدوال عبر window.AndroidBridge */
    public final class Bridge {
        @JavascriptInterface
        public void saveSession(String uid, String refreshToken) {
            if (uid == null || uid.isEmpty() || refreshToken == null || refreshToken.isEmpty()) return;
            Session.save(MainActivity.this, uid, refreshToken);
            runOnUiThread(() -> {
                startNotifyService();
                askIgnoreBatteryOptimizations();
            });
        }

        @JavascriptInterface
        public void clearSession() {
            Session.clear(MainActivity.this);
            stopService(new Intent(MainActivity.this, NotifyService.class));
        }
    }

    /** الروابط الخارجية تُفتح في المتصفح، وموقعك يبقى داخل التطبيق. */
    private final class SiteClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri url = request.getUrl();
            String host = Uri.parse(Config.SITE).getHost();
            if ("file".equals(url.getScheme()) || (host != null && host.equals(url.getHost()))) return false;
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, url));
            } catch (Exception ignored) { }
            return true;
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            if (request.isForMainFrame()) view.loadUrl("file:///android_asset/offline.html");
        }
    }

    /** الموقع يستعمل alert/confirm/prompt، وWebView لا يعرضها بنفسه. */
    private final class Dialogs extends WebChromeClient {
        @Override
        public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
            new AlertDialog.Builder(MainActivity.this)
                    .setMessage(message)
                    .setPositiveButton(R.string.ok, (d, w) -> result.confirm())
                    .setOnCancelListener(d -> result.cancel())
                    .show();
            return true;
        }

        @Override
        public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
            new AlertDialog.Builder(MainActivity.this)
                    .setMessage(message)
                    .setPositiveButton(R.string.ok, (d, w) -> result.confirm())
                    .setNegativeButton(R.string.cancel, (d, w) -> result.cancel())
                    .setOnCancelListener(d -> result.cancel())
                    .show();
            return true;
        }

        @Override
        public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, final JsPromptResult result) {
            final EditText input = new EditText(MainActivity.this);
            input.setText(defaultValue);
            new AlertDialog.Builder(MainActivity.this)
                    .setMessage(message)
                    .setView(input)
                    .setPositiveButton(R.string.ok, (d, w) -> result.confirm(input.getText().toString()))
                    .setNegativeButton(R.string.cancel, (d, w) -> result.cancel())
                    .setOnCancelListener(d -> result.cancel())
                    .show();
            return true;
        }
    }
}
