package com.xdzbar.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

/**
 * خدمة تعمل في الخلفية وتستمع (عبر بثّ Firebase Realtime Database) إلى:
 *   inbox/{uid}      → الرسائل الجديدة
 *   friendReq/{uid}  → طلبات الصداقة
 *   transfers/{uid}  → التحويلات الواردة
 * وتعرض إشعاراً لكل جديد. لا تحتاج خادماً ولا FCM.
 */
public class NotifyService extends Service {

    private static final String CH_SERVICE = "service";
    private static final String CH_ALERTS = "alerts";
    private static final String[] STREAMS = {"inbox", "friendReq", "transfers"};

    private volatile boolean running = false;
    private String idToken;
    private long tokenExpiry = 0;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        createChannels();
        Notification n = foregroundNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }

        if (!Session.has(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }

        if (!running) {
            running = true;
            for (final String stream : STREAMS) {
                new Thread(() -> streamLoop(stream), "sse-" + stream).start();
            }
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        super.onDestroy();
    }

    /* ---------------- القنوات والإشعارات ---------------- */

    private void createChannels() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CH_SERVICE, getString(R.string.ch_service), NotificationManager.IMPORTANCE_MIN));
        nm.createNotificationChannel(new NotificationChannel(CH_ALERTS, getString(R.string.ch_alerts), NotificationManager.IMPORTANCE_HIGH));
    }

    private Notification.Builder builder(String channel) {
        return Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, channel) : new Notification.Builder(this);
    }

    private PendingIntent open(String path, int requestCode) {
        Intent i = new Intent(this, MainActivity.class);
        i.putExtra("path", path);
        i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getActivity(this, requestCode, i, flags);
    }

    private Notification foregroundNotification() {
        Notification.Builder b = builder(CH_SERVICE)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.svc_text))
                .setOngoing(true)
                .setContentIntent(open(null, 0));
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_MIN);
        return b.build();
    }

    private void show(String key, String title, String body, String path) {
        Notification n = builder(CH_ALERTS)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setContentIntent(open(path, key.hashCode()))
                .build();
        getSystemService(NotificationManager.class).notify(key.hashCode(), n);
    }

    /** إشعار واحد لكل عنصر جديد؛ لا نُظهره إن كان التطبيق مفتوحاً أو في اللقطة الأولى. */
    private void alert(boolean suppress, String key, String title, String body, String path) {
        if (!Session.markSeen(this, key)) return;
        if (suppress || MainActivity.visible) return;
        show(key, title, body, path);
    }

    /* ---------------- رمز الدخول ---------------- */

    /** رمز Firebase صالح (ننعشه بواسطة refresh token عند انتهائه). */
    private synchronized String token() throws IOException, JSONException {
        if (idToken != null && System.currentTimeMillis() < tokenExpiry - 60_000) return idToken;

        String refresh = Session.refresh(this);
        if (refresh == null) throw new IOException("no session");

        URL url = new URL("https://securetoken.googleapis.com/v1/token?key=" + Config.API_KEY);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setConnectTimeout(15_000);
        c.setReadTimeout(15_000);
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        c.getOutputStream().write(("grant_type=refresh_token&refresh_token=" + URLEncoder.encode(refresh, "UTF-8")).getBytes("UTF-8"));

        int code = c.getResponseCode();
        if (code == 400) {   // الجلسة أُلغيت: ننهي الخدمة
            Session.clear(this);
            stopSelf();
            throw new IOException("session revoked");
        }
        if (code != 200) throw new IOException("token HTTP " + code);

        JSONObject r = new JSONObject(readAll(c.getInputStream()));
        idToken = r.getString("id_token");
        tokenExpiry = System.currentTimeMillis() + Long.parseLong(r.optString("expires_in", "3600")) * 1000L;
        if (r.has("refresh_token")) Session.updateRefresh(this, r.getString("refresh_token"));
        return idToken;
    }

    private static String readAll(InputStream in) throws IOException {
        BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line);
        return sb.toString();
    }

    /* ---------------- البثّ (Server-Sent Events) ---------------- */

    private void streamLoop(String stream) {
        long backoff = 2_000;

        while (running) {
            try {
                String uid = Session.uid(this);
                if (uid == null) { stopSelf(); return; }

                URL url = new URL(Config.DB_URL + "/" + stream + "/" + uid + ".json?auth=" + token());
                HttpURLConnection c = (HttpURLConnection) url.openConnection();
                c.setRequestProperty("Accept", "text/event-stream");
                c.setConnectTimeout(15_000);
                c.setReadTimeout(120_000);

                int code = c.getResponseCode();
                if (code == 401 || code == 403) idToken = null;   // نجلب رمزاً جديداً في المحاولة التالية
                if (code != 200) throw new IOException("HTTP " + code);

                backoff = 2_000;
                JSONObject tree = new JSONObject();
                boolean first = true;
                BufferedReader reader = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
                String line, event = null;

                while (running && (line = reader.readLine()) != null) {
                    if (line.startsWith("event:")) {
                        event = line.substring(6).trim();
                    } else if (line.startsWith("data:")) {
                        String data = line.substring(5).trim();
                        if ("auth_revoked".equals(event) || "cancel".equals(event)) {
                            idToken = null;
                            throw new IOException(event);
                        }
                        if (!"put".equals(event) && !"patch".equals(event)) continue;

                        apply(tree, event, data);

                        boolean suppress = first && !Session.baselineDone(this, stream);
                        evaluate(stream, tree, suppress);
                        if (first) {
                            first = false;
                            Session.setBaseline(this, stream);
                        }
                    }
                }
            } catch (Exception e) {
                if (!running) return;
                try { Thread.sleep(backoff); } catch (InterruptedException ie) { return; }
                backoff = Math.min(backoff * 2, 60_000);
            }
        }
    }

    /* ---------------- شجرة البيانات ---------------- */

    private void apply(JSONObject tree, String event, String data) throws JSONException {
        JSONObject d = new JSONObject(data);
        String path = d.getString("path");
        Object value = d.isNull("data") ? null : d.get("data");

        if ("patch".equals(event)) {
            if (value instanceof JSONObject) {
                JSONObject patch = (JSONObject) value;
                Iterator<String> keys = patch.keys();
                while (keys.hasNext()) {
                    String k = keys.next();
                    put(tree, ("/".equals(path) ? "" : path) + "/" + k, patch.isNull(k) ? null : patch.get(k));
                }
            }
        } else {
            put(tree, path, value);
        }
    }

    private static void put(JSONObject root, String path, Object value) throws JSONException {
        if ("/".equals(path) || path.isEmpty()) {
            List<String> names = new ArrayList<>();
            Iterator<String> keys = root.keys();
            while (keys.hasNext()) names.add(keys.next());
            for (String name : names) root.remove(name);
            if (value instanceof JSONObject) {
                JSONObject src = (JSONObject) value;
                Iterator<String> it = src.keys();
                while (it.hasNext()) { String k = it.next(); root.put(k, src.get(k)); }
            }
            return;
        }

        String[] parts = path.substring(1).split("/");
        JSONObject cur = root;
        for (int i = 0; i < parts.length - 1; i++) {
            JSONObject next = cur.optJSONObject(parts[i]);
            if (next == null) {
                next = new JSONObject();
                cur.put(parts[i], next);
            }
            cur = next;
        }
        String last = parts[parts.length - 1];
        if (value == null) cur.remove(last);
        else cur.put(last, value);
    }

    /* ---------------- تحويل البيانات إلى إشعارات ---------------- */

    private void evaluate(String stream, JSONObject tree, boolean suppress) {
        Iterator<String> it = tree.keys();
        while (it.hasNext()) {
            String k = it.next();
            JSONObject o = tree.optJSONObject(k);
            if (o == null) continue;

            switch (stream) {
                case "inbox":     // رسالة جديدة غير مقروءة
                    if (o.optBoolean("unread", false)) {
                        String name = o.optString("name", "");
                        String path = "messages.html?chat=" + k + "&name=" + Uri.encode(name) + "&pid=" + Uri.encode(o.optString("pid", ""));
                        alert(suppress, "i:" + k + ":" + o.optLong("ts"),
                                getString(R.string.n_msg_title),
                                getString(R.string.n_msg_body, name.isEmpty() ? "—" : name, o.optString("text", "")), path);
                    }
                    break;

                case "friendReq": // طلب صداقة
                    alert(suppress, "f:" + k + ":" + o.optLong("ts"),
                            getString(R.string.n_friend_title),
                            getString(R.string.n_friend_body, o.optString("fromName", "—")), "friends.html");
                    break;

                case "transfers": // تحويل وارد (أو بيع عملة في P2P)
                    String status = o.optString("status", "");
                    if (!"credited".equals(status) && !"pending".equals(status)) break;
                    String from = o.optString("fromName", "—");
                    String amount = money(o.optDouble("amount", 0));
                    String body = "p2p".equals(o.optString("kind"))
                            ? getString(R.string.n_p2p_body, from, o.optString("qty", ""), o.optString("sym", ""), amount)
                            : getString(R.string.n_transfer_body, from, amount);
                    alert(suppress, "t:" + k, getString(R.string.n_transfer_title), body, "history.html");
                    break;

                default:
                    break;
            }
        }
    }

    private static String money(double v) {
        return v == Math.floor(v) ? String.format(Locale.US, "%,.0f", v) : String.format(Locale.US, "%,.2f", v);
    }
}
