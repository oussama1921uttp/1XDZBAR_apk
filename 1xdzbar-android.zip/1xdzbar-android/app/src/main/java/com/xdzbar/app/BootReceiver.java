package com.xdzbar.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** بعد إعادة تشغيل الهاتف: نعيد تشغيل خدمة الإشعارات إن كان المستخدم مسجّلاً. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()) || !Session.has(context)) return;
        Intent service = new Intent(context, NotifyService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service);
            else context.startService(service);
        } catch (Exception ignored) { }
    }
}
