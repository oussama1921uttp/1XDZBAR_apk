package com.xdzbar.app;

/** إعدادات التطبيق: غيّر SITE إذا تغيّر رابط موقعك. */
final class Config {
    private Config() {}

    static final String SITE = "https://1xdzbar.vercel.app/";

    // نفس إعدادات Firebase المستعملة في الموقع
    static final String API_KEY = "AIzaSyBGainTV-p9V4RSBWayXS4066_bAsUOFQ8";
    static final String DB_URL = "https://xdbar-ab33b-default-rtdb.firebaseio.com";
}
